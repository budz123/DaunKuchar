﻿using Budz.Lopushok.Domain.Entities;
using Budz.Lopushok.infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Budz.Lopushok.Presentation.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        #region fiedls
        public List<Product> _products;
        public List<Product> _displayingProduct;
        private List<ProductType> _productTypes;
        private Product _selectedProduct;
        public List<string> _valuesToFilter;
        private string _searchValue;
        public string _sortValue;
        public string _filterValue;
        #endregion
        #region properties
        public List<string> ValuesToSort => new List<string>()
        {
             "Без сортировки", "По названию (возр)", "По названию (уб)", "По цене (возр)", "По цене (уб)"
        };

        public List<string> ValuesToFilter
        {
            get => _valuesToFilter;
            set
            {
                Set(ref _valuesToFilter, value, nameof(ValuesToFilter));
            }
        }

        public string FilterValue
        {
            get =>_filterValue; 
            set
            {
                Set( ref _filterValue, value, nameof(FilterValue));
                DisplayProducts();
            }
        }
        public string SortValue
        {
            get=> _sortValue;
            set
            {
                Set(ref _sortValue, value, nameof(SortValue));
                DisplayProducts();
            }
        }
        public string SearchValue
        {
            get => _searchValue;
            set
            {
                Set( ref _searchValue, value, nameof(Search));
                DisplayProducts();
            }
        }
        public List<Product> DisplayingProduct
        {
            get => _displayingProduct;
            set
            {
                
               Set( ref _displayingProduct, value, nameof(DisplayingProduct));
                
            }

        }
        public List<ProductType> ProductTypes
        {
            get => _productTypes;
            set
            {
                Set(ref _productTypes, value, nameof(ProductTypes));
            }
        }
        public Product SelectedProduct
        {
            get => _selectedProduct;
            set
            {
                Set(ref _selectedProduct, value, nameof(SelectedProduct));
            }
        }
        #endregion
        public MainViewModel()
        {
            ValuesToFilter = new List<string>();
            ValuesToFilter.Add("Без фильтра");

            FilterValue = ValuesToFilter[0];
            SortValue = ValuesToSort[0];
           
            using (ApplicationDbContext context = new ApplicationDbContext())
            {
                ProductTypes = context.ProductTypes.ToList();

                ProductTypes.ForEach(pt => ValuesToFilter.Add(pt.Title));

                _products = context.Products
                    .Include(p => p.ProductType)
                    .Include(m=>m.ProductMaterials)
                    .ThenInclude(pm => pm.Material)
                    .ToList();
            }
            _displayingProduct = new List<Product>(_products);
        }
        #region Window, Search, Sort, Filter
        private void DisplayProducts()
        {
            DisplayingProduct = Sort(Search(Filter(_products)));
        }


        private List<Product> Search(List<Product> products)
        {
            if ((SearchValue == string.Empty) || (SearchValue == null))
                return products;

            var value = SearchValue.ToLower();
            
            return products.Where(p => p.FullName.ToLower().Contains(value)).ToList();
        }

         private List<Product> Filter(List<Product> products)
        {
            if (FilterValue == ValuesToFilter[0])
                return products;
            else 
                return products.Where(p => p.ProductType.Title == FilterValue).ToList();
        }


        private List<Product> Sort(List<Product> products)
        {

            if (SortValue == ValuesToSort[1])
                return products.OrderBy(p => p.Title).ToList();
            else if (SortValue == ValuesToSort[2])
                return products.OrderByDescending(p => p.Title).ToList();
            else if (SortValue == ValuesToSort[3])
                return products.OrderBy(p => p.TotalCost).ToList();
            else if (SortValue == ValuesToSort[4])
                return products.OrderByDescending(p => p.TotalCost).ToList();
            else
                return products;

        }
        #endregion
    }




}
