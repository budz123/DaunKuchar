﻿using Budz.Lopushok.Domain.Entities;
using Budz.Lopushok.infrastructure.Persistence;
using Budz.Lopushok.Presentation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Budz.Lopushok.Presentation.ViewModels
{
    public class ProductWindowViewModel : ViewModelBase
    {
        private Product _selectedProduct;
        private List<Product> _products;
        private List<ProductType> _productTypes;
        public List<ProductMaterial> _productMaterial;
        private ProductType _selectedProductType;  
        

        public Product SelectedProduct
        {
            get => _selectedProduct;
            set
            {
                Set(ref _selectedProduct, value, nameof(SelectedProduct));
                ProductMaterials = SelectedProduct.ProductMaterials.ToList();
            } 
        }
        public ProductType SelectedProductType
        {
            get => _selectedProductType;
            set => Set(ref _selectedProductType, value, nameof(SelectedProductType));
        }
        public List<Product> Products
        {
            get => _products;
            set => Set(ref _products, value, nameof(Products));
        }
        public List<ProductType> ProductTypes
        {
            get => _productTypes;
            set => Set(ref _productTypes, value, nameof(ProductTypes));
        }
         public List<ProductMaterial> ProductMaterials
        {
            get => _productMaterial;
            set => Set(ref _productMaterial,value, nameof(ProductMaterials));   
        }
        public void SaveChanged()
        {
            using (ApplicationDbContext context = new())
            {
                context.Products.Update(SelectedProduct);
                SelectedProduct.ProductTypeId = SelectedProductType.Id;
                context.SaveChanges();
            }
        }
    }
}
