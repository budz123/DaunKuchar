﻿using Budz.Lopushok.infrastructure.Persistence;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace Budz.Lopushok.Domain.Entities
{
    public partial class Product
    {
        public Product()
        {
            ProductCostHistories = new HashSet<ProductCostHistory>();
            ProductMaterials = new HashSet<ProductMaterial>();
            ProductSales = new HashSet<ProductSale>();
        }
        private string? _image;
        private string _title;
        private decimal _minCostForAgent;
        private string? _fullNameMaterial;

        public int Id { get; set; }
        public string Title { get; set; } 
        public int? ProductTypeId { get; set; }
        public string ArticleNumber { get; set; } = null!;
        public string? Description { get; set; }
        public string? Image
        {
            get => (_image == string.Empty) || (_image == null)
                ? $"..\\Resources\\picture.png"
                : $"..\\Resources{_image.Replace("jpg", "jpeg")}";
            set => _image = value;
        }
        public int? ProductionPersonCount { get; set; }
        public int? ProductionWorkshopNumber { get; set; }
        public decimal MinCostForAgent
        {
            get
            {
                return _minCostForAgent ;
            }
            set
            {
                _minCostForAgent = value;
            }
        }

        public virtual ProductType? ProductType { get; set; }
        public virtual ICollection<ProductCostHistory> ProductCostHistories { get; set; }
        public virtual ICollection<ProductMaterial> ProductMaterials { get; set; }
        public virtual ICollection<ProductSale> ProductSales { get; set; }

        [NotMapped]
        public string FullName
        {
            get 
            {
                var productTypeTitle = ProductType == null ? "Тип" : ProductType.Title; 
                return $"{productTypeTitle} | {Title}";
            }
           
        }

        [NotMapped]
        public decimal TotalCost
        {
            get
            {
                if (ProductMaterials.Count == 0)
                    return MinCostForAgent;
                var totalcost = 0M;
                foreach (var item in ProductMaterials)
                {
                    totalcost += Math.Ceiling((decimal)item.Count) * item.Material.Cost;
                }
                return totalcost;
            }
           
        }
        [NotMapped]
         public string FullNameMaterial
        {
            get
            {
                if(ProductMaterials.Count == 0)
                {
                    return "Отсутсвуют";
                }
                StringBuilder stringBuilder = new();
                foreach (var pm in ProductMaterials)
                {
                    stringBuilder.Append($"{pm.Material.Title}, ");

                }
                stringBuilder.Remove(stringBuilder.Length - 2, 2);
                return stringBuilder.ToString();
                
            }
            
        }
    }
}
