﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace EyeSave.Domain.Entities
{
    public partial class Agent
    {
        private string? _image;

        public Agent()
        {
            AgentPriorityHistories = new HashSet<AgentPriorityHistory>();
            ProductSales = new HashSet<ProductSale>();
            Shops = new HashSet<Shop>();
        }

        public int Id { get; set; }
        public string Title { get; set; } = null!;
        public int AgentTypeId { get; set; }
        public string? Address { get; set; }
        public string Inn { get; set; } = null!;
        public string? Kpp { get; set; }
        public string? DirectorName { get; set; }
        public string Phone { get; set; } = null!;
        public string? Email { get; set; }
        public string? Logo
        {
            get => (_image == string.Empty) || (_image == null) ? $"..\\Resources\\picture.png" : $"..\\Resources{_image}";
            set => _image = value;
        }
        public int Priority { get; set; }

        public virtual AgentType AgentType { get; set; } = null!;
        public virtual ICollection<AgentPriorityHistory> AgentPriorityHistories { get; set; }
        public virtual ICollection<ProductSale> ProductSales { get; set; }
        public virtual ICollection<Shop> Shops { get; set; }
        [NotMapped]
        public int Procentce
        {
            get
            {
                int discount = 0;
                decimal sum = 0M;
                foreach (var item in ProductSales)
                    sum += item.ProductCount * item.Product.MinCostForAgent;
                if (sum <= 10000)
                    discount = 0;
                else if (sum >= 10000 && sum <= 50000) discount = 5;
                else if (sum >= 50000 && sum <= 150000) discount = 10;
                else if (sum >= 150000 && sum <= 500000) discount = 20;
                else if (sum >= 500000) discount = 25;

                return discount;
            }

        }

        [NotMapped]
        public string SalesForYear
        {
            get
            {
                DateTime CustomDateTiem = new DateTime(2019, 12, 1);
                var sales = 0;
                foreach (var sale in ProductSales)
                {
                    if ((CustomDateTiem - sale.SaleDate.Date).TotalDays <= 365)
                    {
                        sales++;
                    }
                }
                return $"{sales} продаж за год";
            }
        }
        [NotMapped]
        public string FullName
        {
            get
            {
                return AgentType.Title + " | " + Title;
            }
        }
    }
}
