﻿using EyeSave.Domain.Entities;
using EyeSave.Infra.Presentences;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace EyeSave.ViewModel
{
    public  class AgentViewModel : ViewModelBase
    {
        private Agent _agents;
        private Window _window;
        private List<AgentType> _agentTypes;

        public List<AgentType> AgentTypes
        {
            get { return _agentTypes; }
            set { _agentTypes = value; }
        }



        public bool Isnew { get; init; }
        public Agent Agent 
        { 
            get => _agents;
            set => Set(ref _agents, value, nameof(Agent));
        }

        public AgentViewModel(int? agentId)
        {
            if (agentId == null)
            {
                Isnew = true;
                Agent = new Agent();
            }
            else
            {
                Isnew = false;
                using (ApplicationDbContext contex = new ApplicationDbContext())
                {
                    Agent = contex.Agents
                        .Include(a => a.AgentType)
                        .Include(a => a.ProductSales)
                        .ThenInclude(s => s.Product)
                        .Single(a => a.Id == agentId);
                    AgentTypes = contex.AgentTypes.ToList();


                }
            
            }
           
        }
    }
}
