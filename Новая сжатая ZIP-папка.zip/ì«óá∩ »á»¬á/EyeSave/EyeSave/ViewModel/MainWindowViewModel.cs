﻿using EyeSave.Domain.Entities;
using EyeSave.Infra.Presentences;
using EyeSave.View;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace EyeSave.ViewModel
{
    public class MainWindowViewModel : ViewModelBase
    {
        public List<string> _valueToFilter;
        public List<Agent> _agent;
        public List<Agent> _displayingAgent;
        private List<AgentType> _agentTypes;

        private Agent _selectedAgents;

        private string _sortValue;
        private string _filtervalue;
        private string _searchValue;
        public List<Agent> Agents { get; set; }

        public Agent SelectedAgents
        {
            get => _selectedAgents;
            set => Set(ref _selectedAgents, value, nameof(SelectedAgents));
        }
        public List<string> ValueToSort => new List<string>()
        {
            "Без сортировки","По названию(Возр.)","По названию(Убыв.)","По Скидке(Возр.)","По Скидке(Убыв.)","По Приоретету(Возр.)","По Приоретету(Убыв.)"
        };

        public List<Agent> DisplayingAgent
        {
            get => _displayingAgent;
            set => Set(ref _displayingAgent, value, nameof(DisplayingAgent));
        }
        public List<AgentType> AgentTypes
        {
            get => _agentTypes;
            set => Set(ref _agentTypes, value, nameof(AgentTypes));
        }
        public List<string> ValueToFilter
        {
            get => _valueToFilter;
            set => Set(ref _valueToFilter, value, nameof(ValueToFilter));
        }
        public string SortValue
        {
            get => _sortValue;
            set
            {
                Set(ref _sortValue, value, nameof(SortValue));
                DisplayAgent();
            }
        }
        public string FilterValue
        {
            get => _filtervalue;
            set
            {
                Set(ref _filtervalue, value, nameof(FilterValue));
                DisplayAgent();
            }

        }
        public string SearchValue
        {
            get => _searchValue;
            set
            {
                Set(ref _searchValue, value, nameof(SearchValue));
                DisplayAgent();
            }
        }
        public MainWindowViewModel()
        {
            ValueToFilter = new List<string>();
            ValueToFilter.Add("Все типы");

           
            using (ApplicationDbContext contxet = new ApplicationDbContext())
            {
                AgentTypes = contxet.AgentTypes.ToList();
                AgentTypes.ForEach(at => ValueToFilter.Add(at.Title));


                _agent = contxet.Agents
                    .Include(a => a.AgentType)
                    .Include(ps => ps.ProductSales)
                    .ThenInclude(p => p.Product)
                    .OrderBy(a => a.Id)
                    .ToList();

            }
            _displayingAgent = new List<Agent>(_agent);
            FilterValue = ValueToFilter[0];
            SortValue = ValueToSort[0];
        }

        private void DisplayAgent()
        {
            DisplayingAgent = ReadeProducts(Sort(Search(Filter(_agent))));
        }
        public List<Agent> Search(List<Agent> agents)
        {
            if ((SearchValue == string.Empty) || (SearchValue == null))
                return agents;
            else
                return agents.Where(p => p.Title.ToLower().Contains(SearchValue.ToLower())
                || p.Email.ToLower().Contains(SearchValue.ToLower())
                || p.Phone.ToLower().Contains(SearchValue.ToLower())).ToList();


        }
        private List<Agent> Filter(List<Agent> agents)
        {
            if (FilterValue == ValueToFilter[0])
                return agents;
            else
                return agents.Where(a => a.AgentType.Title == FilterValue).ToList();
        }
        private List<Agent> Sort(List<Agent> agents)
        {
            if (SortValue == ValueToSort[1])
                return agents.OrderBy(a => a.Title).ToList();
            else if (SortValue == ValueToSort[2])
                return agents.OrderByDescending(a => a.Title).ToList();
            else if (SortValue == ValueToSort[3])
                return agents.OrderBy(a => a.Procentce).ToList();
            else if (SortValue == ValueToSort[4])
                return agents.OrderByDescending(a => a.Procentce).ToList();
            else if (SortValue == ValueToSort[5])
                return agents.OrderBy(a => a.Priority).ToList();
            else if (SortValue == ValueToSort[6])
                return agents.OrderByDescending(a => a.Priority).ToList();
            return agents;

        }


        private int _countPage;
        private int _selectedPage = 1;
        public static MainWindow mainWindow;
        private List<Agent> ReadeProducts(List<Agent> agents)
        {
            if (agents.Count > 20)
            {
                _countPage = Convert.ToInt32(Math.Ceiling((decimal)agents.Count / 20));
                int startItem = _selectedPage * 20 - 20;
                int endItem = _selectedPage * 20;
                List<Agent> list = new();
                for (; startItem < endItem && startItem < agents.Count(); startItem++)
                {
                    list.Add(agents[startItem]);
                }
                ItemPage();
                return list;
            }
            else
                return agents;
        }

        private void ItemPage()
        {
            mainWindow.stackPanelNumber.Children.Clear();

            var leftPage = new TextBlock();
            leftPage.Text = "<";
            leftPage.Margin = new Thickness(5, 0, 0, 0);
            leftPage.FontSize = 15;
            leftPage.MouseDown += LeftPage_MouseDown;
            mainWindow.stackPanelNumber.Children.Add(leftPage);

            for (int i = 1; i <= _countPage; i++)
            {
                var page = new TextBlock();
                page.Text = i.ToString();
                page.Margin = new Thickness(5, 0, 0, 0);
                page.FontSize = 15;
                page.MouseDown += Page_MouseDown;
                if (_selectedPage == i)
                {
                    page.TextDecorations = TextDecorations.Underline;
                }
                mainWindow.stackPanelNumber.Children.Add(page);
            }

            var rigthPage = new TextBlock();
            rigthPage.Text = ">";
            rigthPage.Margin = new Thickness(5, 0, 0, 0);
            rigthPage.FontSize = 15;
            rigthPage.MouseDown += RigthPage_MouseDown;
            mainWindow.stackPanelNumber.Children.Add(rigthPage);
        }

        private void LeftPage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (_selectedPage - 1 > 0)
            {
                _selectedPage -= 1;
                DisplayAgent();
            }
        }
        private void Page_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var textBlock = (sender as TextBlock);
            _selectedPage = Convert.ToInt32(textBlock!.Text);
            DisplayAgent();
        }
        private void RigthPage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (_selectedPage + 1 <= _countPage)
            {
                _selectedPage += 1;
                DisplayAgent();
            }
        }
    }
}
