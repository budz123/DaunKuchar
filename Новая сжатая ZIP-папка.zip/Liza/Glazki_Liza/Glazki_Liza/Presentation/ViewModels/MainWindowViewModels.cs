﻿using Glazki_Liza.Domain.Entities;
using Glazki_Liza.Infrastructure.Presentence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Glazki_Liza.Presentation.ViewModels
{
    public class MainWindowViewModels : ViewModelBase
    {
        private List<Agent> _agents;
        private List<Agent> _displayingAgents;
        private string _sortValue;
        private  List<string> _filtrToValue;

        public List<string> FiltrToValue 
        {
            get { return _filtrToValue; }
            set
            {

                Set(ref _filtrToValue, value, nameof(FiltrToValue));
            }
        }


        public string SortValue
        {
            get { return _sortValue; }
            set
            {
                Set(ref _sortValue, value, nameof(SortValue));
                DisplayAgents();
            }
        }

        private string _searchValue;

        public string SearchValue
        {
            get { return _searchValue; }
            set
            {
                Set(ref _searchValue, value, nameof(SearchValue));
                DisplayAgents();
            }
        }


        public List<string> SortToValue => new List<string>()
        {
            "Без сортировки",
            "По наименование(возр.)",
            "По наименование(убыв.)",
            "По размеру скидки(возр.)",
            "По размеру скидки(убыв.)",
            "По приоритету агента(возр.)",
            "По приоритет агента(убыв.)"
        };


        public List<Agent> DisplayingAgents
        {
            get { return _displayingAgents; }
            set => Set(ref _displayingAgents, value, nameof(DisplayingAgents));
        }


        public MainWindowViewModels()
        {
            using (ApplicationDBContext db = new ApplicationDBContext())
            {
                var agentTypes = db.AgentTypes.ToList();
                FiltrToValue.Add("Все типы");
                agentTypes.ForEach(a => FiltrToValue.Add(a.Title));
                _agents = db.Agents.Include(at => at.AgentType).Include(ps => ps.ProductSales).ThenInclude(p => p.Product).ToList();
            }
            DisplayingAgents = _agents;
            SortValue = SortToValue[0];

        }

        private void DisplayAgents()
        {
            DisplayingAgents = Sort(Search(_agents));
        }

        private List<Agent> Sort(List<Agent> agents)
        {
            if (SortValue == SortToValue[1])
            {
                return agents.OrderBy(a => a.Title).ToList();
            }
            else if (SortValue == SortToValue[2])
            {
                return agents.OrderByDescending(a => a.Title).ToList();
            }
            else if (SortValue == SortToValue[3])
            {
                return agents.OrderBy(a => a.Procent).ToList();
            }
            else if (SortValue == SortToValue[4])
            {
                return agents.OrderByDescending(a => a.Procent).ToList();
            }
            else if (SortValue == SortToValue[5])
            {
                return agents.OrderBy(a => a.Priority).ToList();
            }
            else if (SortValue == SortToValue[6])
            {
                return agents.OrderByDescending(a => a.Priority).ToList();
            }
            else
                return agents;
        }
        private List<Agent> Search(List<Agent> agents)
        {
            if (SearchValue == null || SearchValue == string.Empty)
            {
                return agents;
            }
            else
                return agents.Where(a => a.Title.ToLower().Contains(SearchValue.ToLower())
                || a.Email.ToLower().Contains(SearchValue.ToLower())
                || a.Phone.ToLower().Contains(SearchValue.ToLower())).ToList();
        }
    }
}
